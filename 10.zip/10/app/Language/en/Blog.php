<?php

return [
    'notelp' => 'Call us',
    'email' => 'Email us',
    'headerHome' => 'Home',
    'headerAbout' => 'About',
    'headerProducts' => 'Products',
    'headerActivities' => 'Activities',
    'headerContact' => 'Contact',
    'headerLanguage' => 'Language',
    'btnReadmore' => 'Read More',
    'btnOurproducts' => 'Our Products',
    'titleOurproducts' => 'Products of',
    'titleActivities' => 'Activities of',
    'titleOurContact' => 'Contacts of',
    'titleAboutUs' => 'About Us',
    'titleDescProd' => 'Product Description',
    'titleDescActv' => 'Activities Description',
    'Languange' => 'en',
];
