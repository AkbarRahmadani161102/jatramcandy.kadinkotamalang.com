<!-- Footer Start -->
<div class="container-fluid bg-secondary text-white mt-5 py-5 px-sm-3 px-md-5">
    <div class="row">
        <div class="col-12">
            <div class="copyright border-top pt-4">
                <p class="text-white text-center">
                    &copy; <script>
                        document.write(new Date().getFullYear());
                    </script>. <?php foreach ($profil as $footer) : ?><?= $footer->teks_footer; ?><?php endforeach; ?></a> <!-- License information: https://untree.co/license/ -->
                </p>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->