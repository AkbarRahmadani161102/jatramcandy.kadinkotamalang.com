<?= $this->extend('user/template/template') ?>
<?= $this->Section('content'); ?>

<!-- TEST SLIDER img -->
<?= $this->include('user/home/slider'); ?>

<!-- END slider -->

<br>
<br>

<div class="container-fluid mt-5 mb-5 py-5 py-lg-0 feature">
    <?php foreach ($profil as $title) : ?>
        <h1 class="section-title mb-4 text-center"><?= $title->title_website; ?></h1>
    <?php endforeach; ?>
</div>

<!-- Features End -->
<br>
<br>

<!-- About Start -->
<div class="container-fluid mt-3 mb-5">
    <?php foreach ($profil as $descper) : ?>
        <div class="row align-items-center">
            <div class="col-lg-6 px-0">
                <img width="100%" class="img-fluid ml-4" src="asset-user/images/<?= $descper->foto_utama; ?>" alt="Image">
            </div>
            <div class="col-lg-6 py-5 py-lg-0 px-3 px-lg-5">
                <h5 class="mb-4"><?php echo lang('Blog.titleAboutUs')  ?></h5>
                <h1 class="text-primary mb-3"><?= $descper->nama_perusahaan; ?></h1>
                <p><?php if (lang('Blog.Languange') == 'en') {
                        echo character_limiter($descper->deskripsi_perusahaan_en, 700);
                    } ?>
                    <?php if (lang('Blog.Languange') == 'in') {
                        echo character_limiter($descper->deskripsi_perusahaan_in, 700);
                    } ?></p>
                <div class="button">
                    <a href="about"><?php echo lang('Blog.btnReadmore'); ?></a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<!-- About End -->

<!-- Blog Start -->
<div class="container pt-5">
    <div class="d-flex flex-column text-center mb-5">
        <h5 class="text-primary mb-3"><?php echo lang('Blog.btnOurproducts'); ?></h5>
    </div>
    <div class="row pb-3">
        <?php
        $limitedProducts = array_slice($tbproduk, 0, 3); // Memotong array $tbproduk menjadi 3 elemen pertama
        foreach ($limitedProducts as $produk) :
        ?>
            <div class="col-lg-4 mb-4">
                <div class="card mb-2 p-3">
                    <img data-src="asset-user/images/<?= $produk->foto_produk; ?>" alt="<?php if (lang('Blog.Languange') == 'en') {
                                                                                                echo $produk->nama_produk_en;
                                                                                            } ?>
                                    <?php if (lang('Blog.Languange') == 'in') {
                                        echo $produk->nama_produk_in;
                                    } ?>" class="img-fluid lazyload">
                    <div class="card-body bg-secondary d-flex align-items-center p-0">
                        <h6 class="card-title text-white text-truncate m-0 ml-3">
                            <?php if (lang('Blog.Languange') == 'en') {
                                echo $produk->nama_produk_en;
                            } ?>
                            <?php if (lang('Blog.Languange') == 'in') {
                                echo $produk->nama_produk_in;
                            } ?>
                        </h6>
                        <a href="<?= base_url('product/detail/' . $produk->id_produk . '/' . url_title($produk->nama_produk_en) . '_' . url_title($produk->nama_produk_in)) ?>" class="fa fa-link d-flex flex-shrink-0 align-items-center justify-content-center bg-primary text-white text-decoration-none m-0 ml-auto" style="width: 45px; height: 45px;"></a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="d-flex justify-content-center"> <!-- Menengahkan tombol -->
        <a href="<?= base_url('product') ?>" class="btn btn-lg px-4 btn-primary"><?php echo lang('Blog.btnOurproducts'); ?></a>
    </div>
</div>
<!-- Blog End -->

<?= $this->endSection('content') ?>